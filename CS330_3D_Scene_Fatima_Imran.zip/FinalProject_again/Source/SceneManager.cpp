/***********************************************************
* File: SceneManager.cpp
* Course: CS330 - Computational Graphics and Visualization
* Project: Final Project - 3D Desk Lamp Scnene
* 
* Original Author: Brian Battersby, SNHU
* Modified By: Fatima Imran
* Date: October 16, 2026
* 
* Description: 
* Manages the preparation and rendering of the 3D scene.
* Handles object transformation, textures, materials,
* and lighting to create a realistic desk lamp scene.
* 
* Modifications:
* Customized the scene geormetry, object placement,
* textures, materials, and lighting of the final project.
***********************************************************/

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 * SetupSceneLights()
 * 
 * Configues the lighting used in the 3D lamp scene.
 * A warm primary light illuminates the lamp and tabletop,
 * while a secondary light reduces dark areas.
 * *********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable Phong lighting calculations in the shader.
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// Disable unused light sources
	m_pShaderManager->setBoolValue("directionalLight.bActive", false);
	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// Enable the primary point light for the scene.
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	//Enable the secondary point light for addidtional illumination.
	m_pShaderManager->setBoolValue("pointLights[1].bActive", false);

	// Primary light: warm illumination from above the lamp
	// This light highlights the lampshade and wooden tabletop.

	// Set the position of the primary light.
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		3.0f, 8.0f, 5.0f);

	// Set the ambient color of the primary light.
	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		0.55f, 0.50f, 0.45f);
	
	// Set the diffuse color of the primary light.
	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		1.0f, 0.85f, 0.65f);

	// Set the specular color of the primary light.
	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.0f, 0.9f, 0.8f);

	// Configure attenuation to control how the light intensity decreases with distance.
	m_pShaderManager->setFloatValue(
		"pointLights[0].constant",
		1.0f);

	m_pShaderManager->setFloatValue(
		"pointLights[0].linear",
		0.09f);

	m_pShaderManager->setFloatValue(
		"pointLights[0].quadratic",
		0.032f);

	// Activate the primary point light.
	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);

	// Secondary light: soft, cool illumination from the opposite side
	// This fill light reduces dark areas and improves object visibility

	// Set the position of the secondary light.
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		-4.0f, 5.0f, -3.0f);

	// Set the ambient color of the secondary light.
	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient",
		0.30f, 0.30f, 0.35f);

	// Set the diffuse color of the secondary light.
	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		0.45f, 0.50f, 0.65f);

	// Set the specular color of the secondary light.
	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.5f, 0.55f, 0.7f);

	// Configure attenuation for the secondary light to create a softer lighting effect.
	m_pShaderManager->setFloatValue(
		"pointLights[1].constant",
		1.0f);

	m_pShaderManager->setFloatValue(
		"pointLights[1].linear",
		0.09f);

	m_pShaderManager->setFloatValue(
		"pointLights[1].quadratic",
		0.032f);

	// Activate the secondary point light.
	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load textures used inside in the scene
	CreateGLTexture("textures/wood.jpg", "wood");
	CreateGLTexture("textures/metal.jpg", "metal");
	CreateGLTexture("textures/fabric.jpg", "fabric");

	// Bind textures for rendering
	BindGLTextures();

	// Configure the scene lighting after loading the texture.
	// The light sources will illuminate the lamp and wooden tabletop.
	SetupSceneLights();

	// Define material properties for the wooden tabletop.
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.8f, 0.7f, 0.6f);
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// Define material properties for the metallic lamp components.
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	metalMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.9f);
	metalMaterial.shininess = 64.0f;
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	// Define material properties for the fabric lampshade.
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.diffuseColor = glm::vec3(0.9f, 0.8f, 0.6f);
	fabricMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	fabricMaterial.shininess = 8.0f;
	fabricMaterial.tag = "fabric";
	m_objectMaterials.push_back(fabricMaterial);

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	// Load the primitive meshes used to construct the desk scene.
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadPlaneMesh();

	// Load additional meshes for the book and the coffee mug.
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Configure the scene lights before rendering the objects.
	SetupSceneLights();

	// Draw the surface underneath the desk lamp.
	// The wood texture is tiled across the large plane
	SetTransformations(glm::vec3(12.0f, 1.0f, 8.0f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.0f, 0.0f));
	SetTextureUVScale(4.0f, 4.0f);
	SetShaderTexture("wood");
	// Apply the wood material to control surface lighting.
	SetShaderMaterial("wood");
	m_basicMeshes->DrawPlaneMesh();

	// Reset texture scale before drawing the lamp components
	SetTextureUVScale(1.0f, 1.0f);

	// Draw the circular base of the lamp,
	SetTransformations(glm::vec3(2.2f, 0.35f, 2.2f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.35f, 0.0f));
	SetShaderTexture("metal");
	// Apply reflective metal material to the lamp base.
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Draw the vertical stem of the lamp.
	SetTransformations(glm::vec3(0.30f, 3.8f, 0.30f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 0.65f, 0.0f));
	SetShaderTexture("metal");
	// Apply metallic material to the vertical lamp stem.
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Draw the spherical joint connecting the lamp arm.
	SetTransformations(glm::vec3(0.55f, 0.55f, 0.55f),
		0.0f, 0.0f, 0.0f, glm::vec3(0.0f, 4.45f, 0.0f));
	SetShaderTexture("metal");
	// Apply metallic material to the lamp joint.
	SetShaderMaterial("metal");
	m_basicMeshes->DrawSphereMesh();

	// Draw the angled upper arm of the lamp.
	SetTransformations(glm::vec3(0.28f, 3.0f, 0.28f),
		0.0f, 0.0f, -35.0f, glm::vec3(0.0f, 4.45f, 0.0f));
	SetShaderTexture("metal");
	// Apply metallic materail to the upper lamp arm.
	SetShaderMaterial("metal");
	m_basicMeshes->DrawCylinderMesh();

	// Draw the cone-shaped lamp shade.
	SetTransformations(glm::vec3(1.5f, 1.8f, 1.5f),
		0.0f, 0.0f, 145.0f, glm::vec3(1.75f, 6.85f, 0.0f));
	SetShaderTexture("fabric");
	// Apply the fabric material for softer light reflection.
	SetShaderMaterial("fabric");
	m_basicMeshes->DrawConeMesh();

	// --------------------------------------------------------
	// Book: A rectangular book resting on the wooden tabletop.
	// The box mesh represents the book's cover and page.
	// --------------------------------------------------------

	// Position the book to the left of the desk lamp.
	SetTransformations(
		glm::vec3(2.0f, 0.25f, 1.4f),
		0.0f, -15.0f, 0.0f,
		glm::vec3(-3.0f, 0.15f, 1.0f));

	// Apply a dark blue color to distinguish the book.
	SetShaderColor(0.10f, 0.20f, 0.55f, 1.0f);

	// Apply material properties for lighting.
	SetShaderMaterial("fabric");

	// Draw the book using the box mesh.
	m_basicMeshes->DrawBoxMesh();

	// -----------------------------------------------------
	// Coffee Mug: Main Cylindrical body
	// -----------------------------------------------------

	// Position the mug to the right of the desk lamp.
	SetTransformations(
		glm::vec3(1.0f, 1.5f, 1.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(3.8f, 0.75f, 1.0f));

	// Apply a white ceramic appearance.
	SetShaderColor(0.95f, 0.95f, 0.90f, 1.0f);

	// Apply material properties for lighting.
	SetShaderMaterial("fabric");

	// Draw the cylindrical mug body.
	m_basicMeshes->DrawCylinderMesh();

	// ---------------------------------------------------
	// Coffee Mug: Handle
	// ---------------------------------------------------

	// Position the handle on the right side of the mug.
	SetTransformations(
		glm::vec3(0.45f, 0.65f, 0.45f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(5.3f, 0.85f, 0.0f));

	// Match the white ceramic mug body.
	SetShaderColor(0.95f, 0.95f, 0.90f, 1.0f);
	SetShaderMaterial("fabric");

	// Draw the circular handle.
	m_basicMeshes->DrawTorusMesh();

	// -----------------------------------------------------
	// Second Book: Stacked on top of the first blue book.
	// -----------------------------------------------------

	// Position the second book slightly above the first.
	SetTransformations(
		glm::vec3(1.8f, 0.20f, 1.2f),
		0.0f, -15.0f, 0.0f,
		glm::vec3(-3.0f, 0.42f, 1.0f));

	// Apply a red color to distinguish the second book.
	SetShaderColor(0.65f, 0.15f, 0.20f, 1.0f);

	//Apply material properties for the lighting.
	SetShaderMaterial("fabric");

	// Draw the second book.
	m_basicMeshes->DrawBoxMesh();

	// ----------------------------------------------------
	// Small Potted Plant: Flower Pot
	// ----------------------------------------------------

	// Position the pot towards the back-left of the tabletop.
	SetTransformations(
		glm::vec3(1.2f, 1.2f, 1.2f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-4.0f, 0.6f, -1.5f));

	// Apply terracota color.
	SetShaderColor(0.65f, 0.30f, 0.18f, 1.0f);
	SetShaderMaterial("fabric");

	//Draw the flower pot
	m_basicMeshes->DrawTaperedCylinderMesh();

	// ------------------------------------------------------
	// Small Potted Plant: Green Leaves
	// ------------------------------------------------------

	// First leaf
	SetTransformations(
		glm::vec3(0.25f, 0.65f, 0.25f),
		0.0f, 0.0f, -25.0f,
		glm::vec3(-4.0f, 1.85f, -1.5f));

	SetShaderColor(0.15f, 0.50f, 0.20f, 1.0f);
	SetShaderMaterial("fabric");
	m_basicMeshes->DrawSphereMesh();

	// Second leaf
	SetTransformations(
		glm::vec3(0.35f, 0.85f, 0.35f),
		0.0f, 0.0f, -25.0f,
		glm::vec3(-4.35f, 1.85f, -1.5f));

	SetShaderColor(0.10f, 0.40f, 0.15f, 1.0f);
	SetShaderMaterial("fabric");
	m_basicMeshes->DrawSphereMesh();

	// Third leaf
	SetTransformations(
		glm::vec3(0.35f, 0.95f, 0.35f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(-3.8f, 1.95f, -1.5f));

	SetShaderColor(0.20f, 0.55f, 0.20f, 1.0f);
	SetShaderMaterial("fabric");
	m_basicMeshes->DrawSphereMesh();
}


